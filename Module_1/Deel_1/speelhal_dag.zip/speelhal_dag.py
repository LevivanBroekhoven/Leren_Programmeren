entre = 7.45
antwoord = 45 / 5 

PP = antwoord * 0.37

totale_koste = PP + entre
meerdere = totale_koste * 4
print("prijs per persoon is" ,round(totale_koste,2),'euro')
print("prijs voor 4 personen is" ,round(meerdere,2),'euro')