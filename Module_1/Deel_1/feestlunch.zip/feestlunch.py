crosaint = 0.39*17
stokbrood = 2.78*2
kortingbon = 0.50*3

antwoord = crosaint + stokbrood - kortingbon
print (antwoord)
print (kortingbon)

