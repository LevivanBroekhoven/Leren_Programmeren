crosaintprijs = 0.39*17
stokbroodprijs = 2.78 * 2
kortingbonprijs = 0.50*3
crosaint = 17
stokbrood = 2
kortingbon = 3

antwoord = crosaintprijs + stokbroodprijs - kortingbonprijs
print ("De feestlunch kost je bij de bakker",round(antwoord,2),"euro voor de ",crosaint," crossaints en de ",stokbrood, "stokbroden als de ",kortingbon," kortingsbonnen nog geldig zijn!.")    


# einde Feestlunch #

entre = 7.45
antwoord = 45 / 5 
PP = antwoord * 0.37
totale_koste = PP + entre
meerdere = totale_koste * 4
aantal_mensen = 4
aantal_minuten_VR = 45


print("Dit geweldige dagje-uit met" ,aantal_mensen," mensen in de Speelhal met ",aantal_minuten_VR," minuten VR kost je maar ",round(meerdere,2),"euro")